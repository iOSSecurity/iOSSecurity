# 参考资料

* [Class-dump导出头文件没有属性和方法名怎么处理 - 技能讨论 - 睿论坛](https://iosre.com/t/class-dump/19355/7)
* [iOS逆向攻防实战 - 掘金 (juejin.cn)](https://juejin.cn/post/7073109091320610829)
* [[原创]某App去混淆-iOS安全-看雪论坛-安全社区|安全招聘|bbs.pediy.com](https://bbs.pediy.com/thread-272839.htm)
* [iOS代码混淆工具 — Hikari（支持Xcode14以下全部版本混淆）-Apibug](https://www.apibug.com/tools/1581.html)
* [基于llvm的iOS代码混淆工具 -- Hikari - 简书](https://www.jianshu.com/p/982ac9e211f4)
* [ios手动代码混淆函数和变量名基本原理和注意事项教程(含demo)_小手琴师的博客-CSDN博客_xcode代码混淆](https://blog.csdn.net/boildoctor/article/details/124063406)
* [iOS混淆--OLLVM在iOS中的实践（逻辑混淆） - 简书](https://www.jianshu.com/p/11aa554d5e19)
* 