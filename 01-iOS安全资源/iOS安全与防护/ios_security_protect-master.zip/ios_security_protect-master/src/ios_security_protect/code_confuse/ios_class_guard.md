# iOS Class Guard

* Github
  * Polidea/ios-class-guard: Simple Objective-C obfuscator for Mach-O executables.
    * https://github.com/Polidea/ios-class-guard
